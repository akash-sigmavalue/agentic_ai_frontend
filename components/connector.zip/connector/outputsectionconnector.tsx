"use client";

import { useMemo, useState } from "react";
import type { CompletionResult, ConvStep, GmailAttachmentFile, GmailUiEmail, WorkflowResponse } from "./types";
import AiEmptyState from "./AiEmptyState";
import AiPanelHeader from "./AiPanelHeader";
import WorkflowFormBox from "./WorkflowFormBox";
import GmailActionForm from "./GmailActionForm";
import EditableReplyDraft from "./EditableReplyDraft";

type OutputSectionConnectorProps = {
  response: WorkflowResponse | null;
  completionResult?: CompletionResult | null;
  onSendPrompt?: (prompt: string) => void;
  partialIntent?: Record<string, unknown> | null;
  convStep?: ConvStep;
};

type WorkflowOperationType =
  | "reply"
  | "reply_to_thread"
  | "send"
  | "automate"
  | "fetch"
  | "search"
  | "read"
  | "read_attachment"
  | "analyze"
  | "classify";

function isRecord(value: unknown): value is Record<string, unknown> {
  return Boolean(value && typeof value === "object" && !Array.isArray(value));
}

function firstString(...values: unknown[]) {
  for (const value of values) {
    if (typeof value === "string" && value.trim()) return value.trim();
    if (typeof value === "number") return String(value);
  }
  return "";
}

function normalizeOperation(response: WorkflowResponse | null): WorkflowOperationType {
  const gmailIntent = response?.plan?.gmail_intent;
  const intentRecord = isRecord(gmailIntent) ? gmailIntent : null;
  const rawOperation = firstString(
    intentRecord?.operation,
    intentRecord?.intent,
    intentRecord?.type,
    response?.execution_type === "automated" ? "automate" : response?.execution_type,
  ).toLowerCase();

  const value = rawOperation.replace(/-/g, "_");
  const aliases: Record<string, WorkflowOperationType> = {
    send_email: "send",
    email_send: "send",
    compose_email: "send",
    reply_thread: "reply_to_thread",
    reply_to_email: "reply",
    draft_reply: "reply",
    create_draft: "reply",
    automation_rule: "automate",
    auto_reply: "automate",
    automated: "automate",
    fetch_email: "fetch",
    fetch_emails: "fetch",
    list_email: "fetch",
    list_emails: "fetch",
    search_email: "search",
    search_emails: "search",
    search_threads: "search",
    read_email: "read",
    read_thread: "read",
    get_thread: "read",
    fetch_attachment: "read_attachment",
    read_attachments: "read_attachment",
    summarize: "analyze",
    summarise: "analyze",
    extract: "analyze",
    extraction: "analyze",
    classify_email: "classify",
  };

  if (aliases[value]) return aliases[value];
  if (["reply", "reply_to_thread", "send", "automate", "fetch", "search", "read", "read_attachment", "analyze", "classify"].includes(value)) {
    return value as WorkflowOperationType;
  }

  return response?.plan?.steps?.some((step) => String(step.operation || step.name).toLowerCase().includes("send")) ? "send" : "search";
}

function looksLikeRawGmailPayload(value?: string | null) {
  if (!value) return false;

  const rawMarkers = [
    "payload",
    "headers",
    "DKIM-Signature",
    "ARC-Seal",
    "Received-SPF",
    "X-Google-DKIM-Signature",
    "Authentication-Results",
    "mimeType",
    "historyId",
    "internalDate",
    "raw_mcp_results",
  ];

  return rawMarkers.some((marker) => value.includes(marker));
}

function getResultText(response: WorkflowResponse | null, completionResult: CompletionResult | null) {
  const candidates = [
    completionResult?.reply_sent,
    response?.reply_sent,
    completionResult?.reply_draft,
    response?.reply_draft,
    completionResult?.reply,
    response?.reply,
    response?.analysis,
    response?.final_answer,
    response?.chat_message,
  ];

  for (const item of candidates) {
    if (typeof item === "string" && item.trim() && !looksLikeRawGmailPayload(item)) {
      return item.trim();
    }
  }

  return "";
}

function deepFindString(value: unknown, keys: string[], depth = 0): string {
  if (!value || depth > 5) return "";

  if (Array.isArray(value)) {
    for (const item of value) {
      const found = deepFindString(item, keys, depth + 1);
      if (found) return found;
    }
    return "";
  }

  if (!isRecord(value)) return "";

  for (const key of keys) {
    const direct = value[key];
    if (typeof direct === "string" && direct.trim()) return direct.trim();
    if (typeof direct === "number") return String(direct);
  }

  for (const nested of Object.values(value)) {
    const found = deepFindString(nested, keys, depth + 1);
    if (found) return found;
  }

  return "";
}

function extractThreadId(response: WorkflowResponse | null): string {
  return firstString(
    response?.thread_id,
    response?.partial_intent?.thread_id,
    deepFindString(response?.raw_mcp_results, ["thread_id", "threadId"]),
    deepFindString(response?.step_results, ["thread_id", "threadId"]),
    deepFindString(response?.ui_result?.emails, ["thread_id", "threadId", "id"]),
  );
}

function extractDraftId(response: WorkflowResponse | null): string {
  return firstString(
    response?.draft_id,
    response?.partial_intent?.draft_id,
    deepFindString(response?.raw_mcp_results, ["draft_id", "draftId", "id"]),
    deepFindString(response?.step_results, ["draft_id", "draftId"]),
  );
}

function buildSendEditedReplyPrompt(response: WorkflowResponse | null, editedBody: string) {
  const threadId = extractThreadId(response);
  const subject = firstString(response?.subject, deepFindString(response?.step_results, ["subject"]));
  const recipient = firstString(response?.from_email, deepFindString(response?.step_results, ["from_email", "from"]));

  return [
    "[confirmed] Send edited Gmail reply",
    threadId ? `Thread ID: ${threadId}` : "Thread ID: missing_from_response",
    subject ? `Subject: ${subject}` : "",
    recipient ? `Recipient / To: ${recipient}` : "",
    "Send Directly: true",
    "Operation: send_reply",
    "",
    "Edited Reply Body:",
    editedBody.trim(),
  ]
    .filter(Boolean)
    .join("\n");
}

function buildSaveEditedDraftPrompt(response: WorkflowResponse | null, editedBody: string) {
  const threadId = extractThreadId(response);
  const draftId = extractDraftId(response);

  return [
    "Save this edited Gmail reply as draft",
    threadId ? `Thread ID: ${threadId}` : "Thread ID: missing_from_response",
    draftId ? `Draft ID: ${draftId}` : "",
    "Operation: draft_reply",
    "",
    "Edited Reply Body:",
    editedBody.trim(),
  ]
    .filter(Boolean)
    .join("\n");
}


function countByTool(response: WorkflowResponse | null, patterns: string[]) {
  return (response?.step_results || []).reduce((total, step) => {
    const haystack = `${step.tool || ""} ${step.kind || ""} ${step.step_id || ""}`.toLowerCase();
    return patterns.some((pattern) => haystack.includes(pattern)) ? total + 1 : total;
  }, 0);
}


function isPdfAttachment(file: Partial<GmailAttachmentFile> | null | undefined) {
  const mime = String(file?.mime_type || "").toLowerCase();
  const filename = String(file?.filename || "").toLowerCase();
  return Boolean(file?.is_pdf || mime === "application/pdf" || filename.endsWith(".pdf"));
}

function attachmentKey(file: Partial<GmailAttachmentFile>, index: number) {
  return [file.id, file.message_id, file.attachment_id, file.filename, index].filter(Boolean).join("-");
}

function absoluteFileUrl(url?: string | null) {
  const clean = String(url || "").trim();
  if (!clean) return "";
  if (/^(https?:|blob:|data:)/i.test(clean)) return clean;

  const base =
    process.env.NEXT_PUBLIC_API_BASE_URL ||
    process.env.NEXT_PUBLIC_BACKEND_URL ||
    process.env.NEXT_PUBLIC_API_URL ||
    "";

  const normalizedBase = String(base || "").replace(/\/$/, "");
  if (!normalizedBase) return clean;
  return clean.startsWith("/") ? `${normalizedBase}${clean}` : `${normalizedBase}/${clean}`;
}

function fileSizeLabel(size?: number | null) {
  if (!size || Number.isNaN(size)) return "";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function normalizeAttachment(file: unknown): GmailAttachmentFile | null {
  if (!isRecord(file)) return null;
  const normalized: GmailAttachmentFile = {
    id: typeof file.id === "number" ? file.id : undefined,
    filename: firstString(file.filename, file.name, file.original_filename),
    mime_type: firstString(file.mime_type, file.mimeType, file.content_type),
    attachment_id: firstString(file.attachment_id, file.attachmentId, file.gmail_attachment_id),
    message_id: firstString(file.message_id, file.messageId),
    thread_id: firstString(file.thread_id, file.threadId),
    size: typeof file.size === "number" ? file.size : undefined,
    file_size_bytes: typeof file.file_size_bytes === "number" ? file.file_size_bytes : undefined,
    stored: Boolean(file.stored || file.view_url || file.download_url || file.file_url),
    view_url: firstString(file.view_url, file.file_url),
    download_url: firstString(file.download_url),
    is_pdf: Boolean(file.is_pdf),
  };
  normalized.is_pdf = isPdfAttachment(normalized);
  return normalized.filename || normalized.attachment_id || normalized.id ? normalized : null;
}

function collectPdfAttachments(response: WorkflowResponse | null): GmailAttachmentFile[] {
  const candidates: unknown[] = [];

  if (Array.isArray(response?.pdf_attachments)) candidates.push(...response.pdf_attachments);
  if (Array.isArray(response?.attachments)) candidates.push(...response.attachments);
  if (Array.isArray(response?.ui_result?.pdf_attachments)) candidates.push(...response.ui_result.pdf_attachments);
  if (Array.isArray(response?.ui_result?.attachments)) candidates.push(...response.ui_result.attachments);

  for (const email of response?.ui_result?.emails || []) {
    if (Array.isArray(email.pdf_attachments)) candidates.push(...email.pdf_attachments);
    if (Array.isArray(email.attachments)) candidates.push(...email.attachments);
  }

  const seen = new Set<string>();
  const output: GmailAttachmentFile[] = [];

  for (const item of candidates) {
    const normalized = normalizeAttachment(item);
    if (!normalized || !isPdfAttachment(normalized)) continue;

    const key = [normalized.id, normalized.message_id, normalized.attachment_id, normalized.filename].filter(Boolean).join("|");
    if (seen.has(key)) continue;
    seen.add(key);
    output.push(normalized);
  }

  return output;
}

function PdfAttachmentCard({
  file,
  onView,
}: {
  file: GmailAttachmentFile;
  onView: (file: GmailAttachmentFile) => void;
}) {
  const viewUrl = absoluteFileUrl(file.view_url || file.file_url);
  const downloadUrl = absoluteFileUrl(file.download_url || file.view_url || file.file_url);
  const size = fileSizeLabel(file.file_size_bytes || file.size || null);

  return (
    <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-red-200 bg-red-50/70 p-4 dark:border-red-500/20 dark:bg-red-500/10">
      <div className="min-w-0">
        <div className="flex items-center gap-2">
          <span className="grid h-9 w-9 place-items-center rounded-xl bg-red-500/15 text-lg">📄</span>
          <div className="min-w-0">
            <p className="truncate text-sm font-black text-slate-950 dark:text-white">
              {file.filename || "PDF attachment"}
            </p>
            <p className="mt-0.5 text-xs font-semibold text-slate-500 dark:text-slate-400">
              PDF attachment{size ? ` • ${size}` : ""}{file.stored ? " • stored" : ""}
            </p>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2">
        {viewUrl ? (
          <button
            type="button"
            onClick={() => onView(file)}
            className="rounded-full bg-red-600 px-4 py-2 text-xs font-black text-white shadow-sm hover:bg-red-700"
          >
            View PDF
          </button>
        ) : (
          <span className="rounded-full bg-yellow-500/15 px-3 py-2 text-xs font-bold text-yellow-700 dark:text-yellow-300">
            Download required
          </span>
        )}

        {downloadUrl ? (
          <a
            href={downloadUrl}
            target="_blank"
            rel="noreferrer"
            className="rounded-full border border-slate-200 bg-white px-4 py-2 text-xs font-black text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:hover:bg-slate-800"
          >
            Download
          </a>
        ) : null}
      </div>
    </div>
  );
}

function PdfViewerModal({
  file,
  onClose,
}: {
  file: GmailAttachmentFile | null;
  onClose: () => void;
}) {
  if (!file) return null;

  const url = absoluteFileUrl(file.view_url || file.file_url || file.download_url);
  if (!url) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/70 p-4 backdrop-blur-sm">
      <div className="flex h-[90vh] w-full max-w-6xl flex-col overflow-hidden rounded-[24px] border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-950">
        <div className="flex items-center justify-between gap-3 border-b border-slate-200 p-4 dark:border-slate-800">
          <div className="min-w-0">
            <p className="text-xs font-black uppercase tracking-wide text-red-500">PDF Preview</p>
            <h3 className="truncate text-sm font-black text-slate-950 dark:text-white">
              {file.filename || "PDF attachment"}
            </h3>
          </div>
          <div className="flex shrink-0 gap-2">
            <a
              href={absoluteFileUrl(file.download_url || file.view_url || file.file_url)}
              target="_blank"
              rel="noreferrer"
              className="rounded-full border border-slate-200 px-4 py-2 text-xs font-black text-slate-700 dark:border-slate-700 dark:text-white"
            >
              Open
            </a>
            <button
              type="button"
              onClick={onClose}
              className="rounded-full bg-slate-900 px-4 py-2 text-xs font-black text-white dark:bg-white dark:text-slate-950"
            >
              Close
            </button>
          </div>
        </div>
        <iframe title={file.filename || "PDF attachment"} src={url} className="h-full w-full flex-1 bg-white" />
      </div>
    </div>
  );
}

function PdfAttachmentPanel({
  files,
  onView,
}: {
  files: GmailAttachmentFile[];
  onView: (file: GmailAttachmentFile) => void;
}) {
  if (!files.length) return null;

  return (
    <article className="rounded-[22px] border border-slate-200/70 bg-white/85 p-5 shadow-[0_18px_55px_rgba(15,23,42,0.08)] dark:border-slate-700/80 dark:bg-slate-950/50">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="mb-2 w-fit rounded-full border border-red-500/20 bg-red-500/10 px-2 py-1 text-[10px] font-black uppercase tracking-wide text-red-500">
            PDF Attachments
          </div>
          <h3 className="text-base font-black text-slate-950 dark:text-white">
            Files available from Gmail
          </h3>
        </div>
        <span className="rounded-full bg-red-500/15 px-3 py-1.5 text-xs font-black text-red-600 dark:text-red-300">
          {files.length} PDF{files.length === 1 ? "" : "s"}
        </span>
      </div>
      <div className="space-y-3">
        {files.map((file, index) => (
          <PdfAttachmentCard key={attachmentKey(file, index)} file={file} onView={onView} />
        ))}
      </div>
    </article>
  );
}

function formatEmailSender(email: GmailUiEmail) {
  if (email.from_name && email.from_email && email.from_name !== email.from_email) {
    return `${email.from_name} <${email.from_email}>`;
  }
  return email.from || email.from_email || email.from_name || "Unknown sender";
}

function EmailResultPanel({ response, onViewPdf }: { response: WorkflowResponse; onViewPdf: (file: GmailAttachmentFile) => void }) {
  const result = response.ui_result;
  const emails = result?.emails || [];

  return (
    <article className="rounded-[22px] border border-slate-200/70 bg-white/85 p-5 shadow-[0_18px_55px_rgba(15,23,42,0.08)] dark:border-slate-700/80 dark:bg-slate-950/50">
      <div className="mb-4 flex items-start justify-between gap-3">
        <div>
          <div className="mb-2 w-fit rounded-full border border-red-500/20 bg-red-500/10 px-2 py-1 text-[10px] font-black uppercase tracking-wide text-red-500">
            Gmail Result
          </div>
          <h3 className="text-base font-black text-slate-950 dark:text-white">
            {result?.title || "Processed email result"}
          </h3>
        </div>
        <span className="rounded-full bg-green-500/15 px-3 py-1.5 text-xs font-black text-green-600 dark:text-green-400">
          Clean output
        </span>
      </div>

      {result?.summary ? (
        <p className="mb-4 rounded-2xl border border-slate-200/70 bg-slate-50 p-3 text-sm leading-relaxed text-slate-700 dark:border-slate-800 dark:bg-slate-900/70 dark:text-slate-200">
          {result.summary}
        </p>
      ) : null}

      {emails.length > 0 ? (
        <div className="space-y-3">
          {emails.map((email, index) => (
            <div
              key={email.id || email.thread_id || email.subject || index}
              className="rounded-2xl border border-slate-200 bg-white p-4 shadow-sm dark:border-slate-800 dark:bg-slate-900/80"
            >
              <div className="mb-3 flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <h4 className="break-words text-sm font-black text-slate-950 dark:text-white">
                    {email.subject || "(No subject)"}
                  </h4>
                  <p className="mt-1 break-words text-xs text-slate-500 dark:text-slate-400">
                    From: <span className="font-bold text-slate-700 dark:text-slate-200">{formatEmailSender(email)}</span>
                  </p>
                  {email.to ? (
                    <p className="mt-1 break-words text-xs text-slate-500 dark:text-slate-400">
                      To: <span className="font-medium text-slate-700 dark:text-slate-300">{email.to}</span>
                    </p>
                  ) : null}
                </div>
                {email.date ? (
                  <span className="shrink-0 rounded-full bg-slate-100 px-2.5 py-1 text-[11px] font-bold text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                    {email.date}
                  </span>
                ) : null}
              </div>

              {email.body_preview || email.snippet ? (
                <p className="max-h-72 overflow-auto whitespace-pre-wrap rounded-xl bg-slate-50 p-3 text-sm leading-6 text-slate-700 dark:bg-slate-950/70 dark:text-slate-200">
                  {email.body_preview || email.snippet}
                </p>
              ) : null}

              {!!email.attachments?.length ? (
                <div className="mt-3 flex flex-wrap gap-2">
                  {email.attachments.map((file, fileIndex) => {
                    const normalized = normalizeAttachment(file);
                    const isPdf = isPdfAttachment(normalized);
                    const canView = Boolean(normalized?.view_url || normalized?.file_url);

                    if (isPdf && normalized && canView) {
                      return (
                        <button
                          type="button"
                          key={`${normalized.filename}-${fileIndex}`}
                          onClick={() => onViewPdf(normalized)}
                          className="rounded-full bg-red-500/10 px-3 py-1 text-xs font-bold text-red-600 hover:bg-red-500/20 dark:text-red-300"
                        >
                          📄 View {normalized.filename || "PDF"}
                        </button>
                      );
                    }

                    return (
                      <span
                        key={`${normalized?.filename || file.filename}-${fileIndex}`}
                        className="rounded-full bg-blue-500/10 px-3 py-1 text-xs font-bold text-blue-600 dark:text-blue-300"
                      >
                        {isPdf ? "📄" : "📎"} {normalized?.filename || file.filename || "Attachment"}
                      </span>
                    );
                  })}
                </div>
              ) : null}
            </div>
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-slate-300 p-4 text-sm text-slate-600 dark:border-slate-700 dark:text-slate-300">
          Backend returned a clean result object, but no readable email items were included.
        </div>
      )}
    </article>
  );
}

export default function OutputSectionConnector({
  response,
  completionResult = null,
  onSendPrompt,
  partialIntent = null,
  convStep = "idle",
}: OutputSectionConnectorProps) {
  const [selectedPdf, setSelectedPdf] = useState<GmailAttachmentFile | null>(null);
  const pdfAttachments = useMemo(() => collectPdfAttachments(response), [response]);
  const operationType = normalizeOperation(response);
  const editableDraftText = firstString(response?.reply_draft, completionResult?.reply_draft);
  const hasEditableDraft = Boolean(editableDraftText && !looksLikeRawGmailPayload(editableDraftText));
  const resultText = response?.ui_result || hasEditableDraft ? "" : getResultText(response, completionResult);
  const uiEmails = response?.ui_result?.emails || [];
  const hasUiResult = Boolean(response?.ui_result);
  const hasForm = Boolean(response?.requires_form && response?.form_schema);
  const threadId = extractThreadId(response);
  const draftId = extractDraftId(response);
  const draftSubject = firstString(response?.subject, deepFindString(response?.step_results, ["subject"]));
  const draftRecipient = firstString(response?.from_email, deepFindString(response?.step_results, ["from_email", "from"]));
  const hasOutput = Boolean(hasForm || hasEditableDraft || hasUiResult || pdfAttachments.length || response || completionResult || resultText);
  const emailsFound = uiEmails.length || response?.emails_found || countByTool(response, ["search", "fetch", "thread", "email"]);
  const repliesGenerated = response?.replies_generated || countByTool(response, ["generate", "compose", "reply"]);
  const repliesSent = response?.replies_sent_count || countByTool(response, ["send", "reply_to_thread"]);
  const showForm = Boolean(!response?.requires_form && response && onSendPrompt && (convStep === "waiting_email" || convStep === "waiting_field"));

  return (
    <>
    <PdfViewerModal file={selectedPdf} onClose={() => setSelectedPdf(null)} />
    <section className="flex min-h-[690px] flex-col overflow-hidden rounded-[24px] border border-slate-200/70 bg-white/85 shadow-[0_22px_70px_rgba(15,23,42,.10)] dark:border-slate-700/80 dark:bg-slate-900/85">
      <AiPanelHeader
        icon="📤"
        kicker="Output"
        title="Processed Emails"
        right={
          <button
            type="button"
            onClick={() => onSendPrompt?.("Create a new Gmail automation rule")}
            className="rounded-full border border-slate-200 bg-white px-3 py-1.5 text-xs font-bold text-slate-700 dark:border-slate-700 dark:bg-slate-800 dark:text-white"
          >
            ⊕ New rule
          </button>
        }
      />

      <div className="flex-1 overflow-auto p-5">
        {!hasOutput ? (
          <AiEmptyState
            icon="✨"
            title="Waiting for AI Output"
            text="Clean email cards, summaries, generated replies, and extracted details will appear here. Workflow steps stay in the workflow panel."
          />
        ) : (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border border-dashed border-yellow-400/60 bg-yellow-500/10 p-4 text-sm text-slate-800 dark:text-slate-100">
              <span>✅ ✨ Processed {emailsFound || 0} emails</span>
              <div className="flex gap-2">
                <span className="rounded-full bg-blue-500/15 px-3 py-1.5 text-xs font-black text-blue-500">Generated {repliesGenerated || 0}</span>
                <span className="rounded-full bg-green-500/15 px-3 py-1.5 text-xs font-black text-green-500">Sent {repliesSent || 0}</span>
              </div>
            </div>


            {response?.requires_form && response?.form_schema && onSendPrompt ? (
              <GmailActionForm
                schema={response.form_schema}
                originalPrompt={String(response.partial_intent?.original_prompt || response.plan?.goal || "")}
                partialIntent={partialIntent}
                onSubmit={(nextPrompt) => onSendPrompt(nextPrompt)}
              />
            ) : null}

            <PdfAttachmentPanel files={pdfAttachments} onView={setSelectedPdf} />

            {response?.ui_result ? <EmailResultPanel response={response} onViewPdf={setSelectedPdf} /> : null}

            {hasEditableDraft ? (
              <EditableReplyDraft
                initialBody={editableDraftText}
                threadId={threadId || null}
                draftId={draftId || null}
                subject={draftSubject || null}
                recipient={draftRecipient || null}
                fromEmail={response?.from_email || null}
                onSend={(editedBody) => onSendPrompt?.(buildSendEditedReplyPrompt(response, editedBody))}
                onSaveDraft={(editedBody) => onSendPrompt?.(buildSaveEditedDraftPrompt(response, editedBody))}
                onRegenerate={() =>
                  onSendPrompt?.(
                    `Regenerate the Gmail reply for this same thread using a professional tone. Original goal: ${response?.plan?.goal || "reply to email"}`,
                  )
                }
              />
            ) : null}

            {resultText ? (
              <article className="rounded-[22px] border border-slate-200/70 bg-white/80 p-5 shadow-[0_18px_55px_rgba(15,23,42,0.08)] dark:border-slate-700/80 dark:bg-slate-900/70">
                <div className="mb-2 w-fit rounded-full border border-blue-500/20 bg-blue-500/10 px-2 py-1 text-[10px] font-black uppercase tracking-wide text-blue-500">AI Result</div>
                <p className="whitespace-pre-wrap text-sm leading-relaxed text-slate-700 dark:text-slate-200">{resultText}</p>
              </article>
            ) : null}

            {showForm && response ? (
              <div className="rounded-[22px] border border-slate-200/70 bg-white/80 p-4 dark:border-slate-700/80 dark:bg-slate-950/40">
                <WorkflowFormBox
                  key={`${operationType}-${response.from_email || ""}-${response.subject || ""}-${response.execution_type || ""}`}
                  response={response}
                  partialIntent={partialIntent}
                  operationType={operationType}
                  onRerun={(nextPrompt) => onSendPrompt?.(nextPrompt)}
                />
              </div>
            ) : null}
          </div>
        )}
      </div>
    </section>
    </>
  );
}
