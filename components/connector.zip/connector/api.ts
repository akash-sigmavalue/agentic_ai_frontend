"use client";

import type { PromptToWorkflowResponse } from "../../types/api";
import { API_BASE_URL, CONNECTOR_API_ROUTES, apiUrl } from "../../lib/api-client";
import type { StreamStep } from "./types";

export interface GoogleOAuthStartResponse {
  auth_url: string;
}

export interface GmailConnectionStatusResponse {
  connected: boolean;
  email?: string | null;
}

export interface ConnectorHealthResponse {
  active_rules: number;
  users_with_active_watch: number;
  rules_executed_last_24h: number;
  rules_failed_last_24h: number;
  scheduler_running: boolean;
}

export interface AutomationRuleSummary {
  id: number;
  user_id?: number;
  connector_type?: string | null;
  execution_type?: string | null;
  trigger_type?: string | null;
  sender_name?: string | null;
  sender_email?: string | null;
  subject_filter?: string | null;
  keyword_filter?: string[];
  operation?: string | null;
  tone?: string | null;
  output_requirement?: Record<string, unknown>;
  is_active?: boolean;
  last_processed_message_id?: string | null;
  created_at?: string | null;
  updated_at?: string | null;
  last_execution_status?: string | null;
  last_execution_message_id?: string | null;
  last_execution_action?: string | null;
}

export interface AutomationRulesResponse {
  rules: AutomationRuleSummary[];
}

export interface AutomationRuleExecutionLog {
  id: number;
  matched_message_id: string;
  status: string;
  action_taken: string;
  error_message?: string | null;
  created_at: string;
}

export interface AutomationRuleStatsResponse {
  rule_id: number;
  total_executions: number;
  successful: number;
  failed: number;
  skipped: number;
  last_executed_at?: string | null;
  success_rate: number;
}

export interface ContinueMissingFieldRequest {
  missing_field: string;
  user_answer: string;
  partial_intent: Record<string, unknown>;
}

export interface ContinueMissingFieldResponse {
  status: "automation_rule_created" | "one_time_completed" | "needs_clarification";
  message: string;
  rule_id?: number;
  execution_type?: "automated" | "one_time";
  summary?: string;
  final_answer?: string;
  success?: boolean;
  missing_field?: string;
  question?: string;
  field_type?: "email" | "choice" | "text" | "text_optional";
  field_options?: string[];
  field_skippable?: boolean;
  partial_intent?: Record<string, unknown>;
}

export interface SaveAutomationFlowRequest {
  flow: Record<string, unknown>;
}

export interface SaveAutomationFlowResponse {
  status: "saved";
  rule_id: number;
}

export type AttachmentContentResponse = Record<string, unknown>;

export interface GenerateAutomationFlowRequest {
  prompt: string;
}

export interface GenerateAutomationFlowResponse {
  can_execute: boolean;
  flow: Record<string, unknown>;
  ui_schema?: Record<string, unknown>;
}

export const API_BASE = API_BASE_URL;

function getToken(): string {
  if (typeof window === "undefined") return "";
  return localStorage.getItem("token") || "";
}

async function apiFetch<T>(path: string, init: RequestInit = {}): Promise<T> {
  const token = getToken();
  const headers = new Headers(init.headers || {});

  const isFormData =
    init.body instanceof FormData ||
    headers.get("Content-Type") === "application/x-www-form-urlencoded";

  if (!isFormData && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  if (token) {
    headers.set("Authorization", `Bearer ${token}`);
  }

  let response: Response;
  try {
    response = await fetch(apiUrl(path), {
      ...init,
      headers,
    });
  } catch (error) {
    console.error("API network error", {
      path,
      apiBase: API_BASE,
      error,
    });
    throw new Error(`Unable to reach backend at ${API_BASE}. Is it running?`);
  }

  if (!response.ok) {
    const message = await response.text();
    console.error("API request failed", {
      path,
      status: response.status,
      statusText: response.statusText,
      body: message,
    });

    if (response.status === 401 || response.status === 403) {
      if (typeof window !== "undefined") {
        localStorage.removeItem("token");
      }
      throw new Error("Session expired. Please log in again.");
    }

    throw new Error(message || `Request failed with status ${response.status}`);
  }

  if (response.status === 204) {
    return undefined as T;
  }

  const contentType = response.headers.get("content-type") || "";
  if (contentType.includes("application/json")) {
    return (await response.json()) as T;
  }

  return (await response.text()) as T;
}

export function parseCommaList(value: string): string[] {
  return value
    .split(",")
    .map((item) => item.trim())
    .filter(Boolean);
}

export function registerUser(payload: {
  username: string;
  email: string;
  password: string;
}) {
  return apiFetch("/auth/register", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function loginUser(payload: { username: string; password: string }) {
  const body = new URLSearchParams();
  body.append("username", payload.username);
  body.append("password", payload.password);

  return apiFetch<{ access_token: string; token_type: string }>("/auth/login", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: body.toString(),
  });
}

export function processWorkflow(
  prompt: string,
): Promise<PromptToWorkflowResponse> {
  return apiFetch<PromptToWorkflowResponse>(CONNECTOR_API_ROUTES.processWorkflow, {
    method: "POST",
    body: JSON.stringify({ prompt }),
  });
}

export function startGoogleOAuth(): Promise<GoogleOAuthStartResponse> {
  return apiFetch<GoogleOAuthStartResponse>(CONNECTOR_API_ROUTES.googleOAuthStart, {
    method: "GET",
  });
}

export function getGmailConnectionStatus(): Promise<GmailConnectionStatusResponse> {
  return apiFetch<GmailConnectionStatusResponse>(CONNECTOR_API_ROUTES.gmailStatus, {
    method: "GET",
  });
}

export function continueMissingField(
  payload: ContinueMissingFieldRequest,
): Promise<ContinueMissingFieldResponse> {
  return apiFetch<ContinueMissingFieldResponse>(CONNECTOR_API_ROUTES.continueMissingField, {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function fetchAttachment(
  messageId: string,
  attachmentId: string,
  filename?: string,
  mimeType?: string,
): Promise<AttachmentContentResponse> {
  const query = new URLSearchParams();
  if (filename) {
    query.set("filename", filename);
  }
  if (mimeType) {
    query.set("mime_type", mimeType);
  }

  const suffix = query.toString() ? `?${query.toString()}` : "";
  const path = `/connectors/attachment/${encodeURIComponent(messageId)}/${encodeURIComponent(attachmentId)}${suffix}`;

  return apiFetch<AttachmentContentResponse>(path, {
    method: "GET",
  });
}

export function getAutomationHealth(): Promise<ConnectorHealthResponse> {
  return apiFetch<ConnectorHealthResponse>("/connectors/automation/health", {
    method: "GET",
  });
}

export function listAutomationRules(): Promise<AutomationRulesResponse> {
  return apiFetch<AutomationRulesResponse>("/connectors/automation/rules", {
    method: "GET",
  });
}

export function toggleAutomationRule(
  ruleId: number,
  isActive: boolean
): Promise<{ success: boolean; rule: AutomationRuleSummary }> {
  return apiFetch<{ success: boolean; rule: AutomationRuleSummary }>(
    `/connectors/automation/rules/${ruleId}`,
    {
      method: "PATCH",
      body: JSON.stringify({ is_active: isActive }),
    }
  );
}

export function getAutomationRuleLogs(
  ruleId: number,
): Promise<AutomationRuleExecutionLog[]> {
  return apiFetch<AutomationRuleExecutionLog[]>(
    `/connectors/automation/rules/${ruleId}/logs`,
    {
      method: "GET",
    },
  );
}

export function getAutomationRuleStats(
  ruleId: number,
): Promise<AutomationRuleStatsResponse> {
  return apiFetch<AutomationRuleStatsResponse>(
    `/connectors/automation/rules/${ruleId}/stats`,
    {
      method: "GET",
    },
  );
}

export function saveAutomationFlow(
  payload: SaveAutomationFlowRequest,
): Promise<SaveAutomationFlowResponse> {
  return apiFetch<SaveAutomationFlowResponse>("/connectors/automation/flow/save", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

export function generateAutomationFlow(
  payload: GenerateAutomationFlowRequest,
): Promise<GenerateAutomationFlowResponse> {
  return apiFetch<GenerateAutomationFlowResponse>("/connectors/automation/flow/generate", {
    method: "POST",
    body: JSON.stringify(payload),
  });
}

// Backward-compatible alias if old components still call this name.
export const planConnectorWorkflow = processWorkflow;

export interface StreamWorkflowOptions {
  prompt: string;
  onStep: (step: StreamStep) => void;
  onComplete: (result: Record<string, unknown>) => void;
  onError: (error: string) => void;
  signal?: AbortSignal;
}

export async function streamWorkflowRun({
  prompt,
  onStep,
  onComplete,
  onError,
  signal,
}: StreamWorkflowOptions): Promise<void> {
  const token = typeof window !== "undefined" ? localStorage.getItem("token") || "" : "";

  let response: Response;
  try {
    response = await fetch(apiUrl("/connectors/workflow/run/stream"), {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: token ? `Bearer ${token}` : "",
      },
      body: JSON.stringify({ prompt }),
      signal,
    });
  } catch (err) {
    onError(err instanceof Error ? err.message : "Network error connecting to stream");
    return;
  }

  if (!response.ok) {
    const text = await response.text().catch(() => `HTTP ${response.status}`);
    if (response.status === 401 || response.status === 403) {
      if (typeof window !== "undefined") localStorage.removeItem("token");
      onError("Session expired. Please log in again.");
    } else {
      onError(text || `Request failed with status ${response.status}`);
    }
    return;
  }

  const reader = response.body?.getReader();
  if (!reader) {
    onError("No response body from streaming endpoint");
    return;
  }

  const decoder = new TextDecoder();
  let buffer = "";

  try {
    while (true) {
      const { done, value } = await reader.read();
      if (done) break;

      buffer += decoder.decode(value, { stream: true });
      const parts = buffer.split(/\n\n/);
      buffer = parts.pop() ?? "";

      for (const part of parts) {
        const trimmed = part.trim();
        if (!trimmed || trimmed.startsWith(":")) continue;

        const dataLine = trimmed
          .split("\n")
          .filter((l) => l.startsWith("data:"))
          .map((l) => l.slice(5).trim())
          .join("");

        if (!dataLine) continue;

        let parsed: Record<string, unknown>;
        try {
          parsed = JSON.parse(dataLine);
        } catch {
          continue;
        }

        const eventType = parsed.type as string | undefined;

        if (eventType === "step_complete") {
          onStep(parsed as unknown as StreamStep);
        } else if (eventType === "workflow_complete") {
          onComplete((parsed.result as Record<string, unknown>) ?? {});
        } else if (eventType === "error") {
          onError(String(parsed.error ?? "Unknown streaming error"));
        }
      }
    }
  } catch (err) {
    if ((err as Error)?.name !== "AbortError") {
      onError(err instanceof Error ? err.message : "Streaming error");
    }
  } finally {
    reader.releaseLock();
  }
}

export async function searchKeyword(
  keyword: string,
  emails: any[] = [],
  threads: any[] = [],
  attachments: any[] = []
): Promise<any> {
  const token = localStorage.getItem("token");
  const response = await fetch(`${API_BASE_URL}/connectors/search/keyword`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
    },
    body: JSON.stringify({ keyword, emails, threads, attachments }),
  });

  if (!response.ok) {
    let errorDetail = "Failed to search keyword";
    try {
      const errorData = await response.json();
      errorDetail = errorData.detail || errorDetail;
    } catch {}
    throw new Error(errorDetail);
  }

  return response.json();
}
