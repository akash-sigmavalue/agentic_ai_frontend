"use client";

import type { ReactNode } from "react";

type AiMetricCardProps = {
  icon: ReactNode;
  label: string;
  value: string | number;
  note?: string;
  color?: "red" | "blue" | "green" | "yellow";
};

const colorMap = {
  red: "bg-red-500/15 text-red-500",
  blue: "bg-blue-500/15 text-blue-500",
  green: "bg-green-500/15 text-green-500",
  yellow: "bg-yellow-500/15 text-yellow-500",
};

export default function AiMetricCard({
  icon,
  label,
  value,
  note,
  color = "blue",
}: AiMetricCardProps) {
  return (
    <div className="relative overflow-hidden rounded-[22px] border border-slate-200/70 bg-white/80 p-5 shadow-[0_18px_55px_rgba(15,23,42,0.08)] dark:border-slate-700/80 dark:bg-slate-900/80">
      <div className="relative z-10 flex items-center gap-4">
        <div className={`grid h-11 w-11 place-items-center rounded-full text-xl ${colorMap[color]}`}>
          {icon}
        </div>
        <div className="min-w-0">
          <div className="truncate text-[10px] font-black uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
            {label}
          </div>
          <div className="mt-1 text-2xl font-black leading-none text-slate-950 dark:text-white">
            {value} {note ? <span className="text-xs font-semibold text-slate-500 dark:text-slate-400">{note}</span> : null}
          </div>
        </div>
      </div>
      <div className="absolute -bottom-16 left-0 right-0 h-28 bg-blue-500/10 blur-2xl" />
    </div>
  );
}
