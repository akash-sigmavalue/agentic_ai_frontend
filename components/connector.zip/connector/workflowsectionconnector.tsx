"use client";

import type { CompletionResult, ConvStep, StreamStep, WorkflowResponse } from "./types";
import AiEmptyState from "./AiEmptyState";
import AiPanelHeader from "./AiPanelHeader";
import AiWorkflowStepCard from "./AiWorkflowStepCard";

type WorkflowSectionConnectorProps = {
  response: WorkflowResponse | null;
  needsGmail: boolean;
  gmailConnected: boolean;
  gmailEmail: string | null;
  pendingPrompt: string | null;
  isLoading: boolean;
  connectorStatusLoading: boolean;
  handleConnectGmail: () => void;
  handleRecheckGmailConnection: () => void;
  handleContinueWorkflow: () => void;
  handleActivateFlow: () => void;
  activatingFlow: boolean;
  activateFlowResult: { ok: boolean; message: string } | null;
  completionResult?: CompletionResult | null;
  convStep?: ConvStep;
  streamingSteps?: StreamStep[];
};

function prettyTitle(value: string, index: number) {
  const clean = value.replace(/[_-]/g, " ").replace(/\s+/g, " ").trim();
  const title = clean ? clean.replace(/\b\w/g, (letter) => letter.toUpperCase()) : `Step ${index + 1}`;
  return `${String(index + 1).padStart(2, "0")} ${title}`;
}

function stepEmoji(name: string, system?: string | null) {
  const key = `${name} ${system || ""}`.toLowerCase();
  if (key.includes("auth") || key.includes("oauth") || key.includes("connect")) return "🔐";
  if (key.includes("intent") || key.includes("plan") || key.includes("classify")) return "🧭";
  if (key.includes("search") || key.includes("fetch") || key.includes("list")) return "📬";
  if (key.includes("attachment") || key.includes("parse") || key.includes("read")) return "📎";
  if (key.includes("summary") || key.includes("summar") || key.includes("analy") || key.includes("extract")) return "🧠";
  if (key.includes("reply") || key.includes("draft") || key.includes("send")) return "✍️";
  if (key.includes("automation") || key.includes("rule") || key.includes("trigger")) return "⚡";
  return "✨";
}

function buildWorkflowCards(response: WorkflowResponse | null, streamingSteps: StreamStep[] = []) {
  if (streamingSteps.length > 0) {
    return streamingSteps.map((step, index) => ({
      emoji: stepEmoji(step.name),
      title: prettyTitle(step.name, index),
      desc: step.output || step.error || "Live workflow step",
      tag: step.step_id || step.status,
      ms: step.duration_ms ?? null,
      status: step.status,
    }));
  }

  return (
    response?.plan?.steps?.map((step, index) => ({
      emoji: stepEmoji(step.name || step.operation || "", step.system),
      title: prettyTitle(step.name || step.operation || step.kind || "workflow step", index),
      desc: step.description || step.operation || step.system || "Prepared by AI planner",
      tag: step.system ? `${step.system}.${step.operation || step.kind}` : step.operation || step.kind,
      ms: null,
      status: "planned",
    })) ?? []
  );
}

function countStatus(response: WorkflowResponse | null, streamingSteps: StreamStep[] = []) {
  if (streamingSteps.length > 0) {
    const completed = streamingSteps.filter((item) => String(item.status).toLowerCase().includes("complete") || String(item.status).toLowerCase().includes("success")).length;
    const failed = streamingSteps.filter((item) => String(item.status).toLowerCase().includes("fail") || String(item.status).toLowerCase().includes("error")).length;
    return { completed, failed };
  }

  const results = response?.step_results || [];
  const completed = results.filter((item) => String(item.status).toLowerCase().includes("success") || String(item.status).toLowerCase().includes("complete")).length;
  const failed = results.filter((item) => String(item.status).toLowerCase().includes("fail") || String(item.status).toLowerCase().includes("error")).length;
  return { completed, failed };
}

export default function WorkflowSectionConnector({
  response,
  needsGmail,
  gmailConnected,
  gmailEmail,
  pendingPrompt,
  isLoading,
  connectorStatusLoading,
  handleConnectGmail,
  handleRecheckGmailConnection,
  handleContinueWorkflow,
  handleActivateFlow,
  activatingFlow,
  activateFlowResult,
  completionResult = null,
  convStep = "idle",
  streamingSteps = [],
}: WorkflowSectionConnectorProps) {
  const cards = buildWorkflowCards(response, streamingSteps);
  const { completed, failed } = countStatus(response, streamingSteps);
  const activeCard = cards.find((item) => String(item.status).toLowerCase() === "running") || cards[cards.length - 1];
  const statusTitle = completionResult ? "Complete" : isLoading || convStep === "streaming" || convStep === "submitting" ? "Running" : cards.length ? "Planned" : "AI Waiting";
  const liveTool = isLoading && activeCard ? activeCard.tag : completionResult ? "idle" : cards[0]?.tag || "—";

  return (
    <section className="flex min-h-[690px] flex-col overflow-hidden rounded-[24px] border border-slate-200/70 bg-white/85 shadow-[0_22px_70px_rgba(15,23,42,.10)] dark:border-slate-700/80 dark:bg-slate-900/85">
      <AiPanelHeader
        icon="🛠️"
        kicker="Workflow"
        title="AI Agent Execution"
        right={
          <span className={`rounded-full px-3 py-1.5 text-[10px] font-black uppercase tracking-widest ${completionResult ? "bg-green-500/15 text-green-500" : isLoading ? "bg-blue-500/15 text-blue-500" : "bg-slate-200 text-slate-500 dark:bg-slate-800 dark:text-slate-300"}`}>
            {statusTitle}
          </span>
        }
      />

      <div className="flex-1 overflow-auto p-5">
        {needsGmail && pendingPrompt ? (
          <div className="mb-4 rounded-[22px] border border-red-500/30 bg-red-500/10 p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-sm font-black text-slate-950 dark:text-white">🔐 Gmail connection required</div>
                <p className="mt-1 text-sm leading-relaxed text-slate-600 dark:text-slate-300">
                  {gmailConnected ? `Connected as ${gmailEmail || "Gmail user"}. Continue the pending workflow.` : "Connect Gmail, then recheck the connection to continue this workflow."}
                </p>
                {pendingPrompt ? <p className="mt-2 line-clamp-2 text-xs text-slate-500 dark:text-slate-400">Pending: {pendingPrompt}</p> : null}
              </div>
              <div className="flex shrink-0 flex-col gap-2">
                {!gmailConnected ? (
                  <button onClick={handleConnectGmail} className="rounded-full bg-red-500 px-4 py-2 text-xs font-black text-white">Connect Gmail</button>
                ) : (
                  <button onClick={handleContinueWorkflow} disabled={isLoading} className="rounded-full bg-green-500 px-4 py-2 text-xs font-black text-white disabled:opacity-60">Continue</button>
                )}
                <button onClick={handleRecheckGmailConnection} disabled={connectorStatusLoading} className="rounded-full border border-slate-300 px-4 py-2 text-xs font-bold text-slate-700 disabled:opacity-60 dark:border-slate-700 dark:text-slate-200">
                  {connectorStatusLoading ? "Checking..." : "Recheck"}
                </button>
              </div>
            </div>
          </div>
        ) : null}

        {cards.length === 0 ? (
          <AiEmptyState
            icon="⚙️"
            title="AI workflow plan will appear here"
            text="Run a prompt to see neural planning, tool selection, Gmail API calls, and summarization steps."
          />
        ) : (
          <>
            <div className="mb-4 grid grid-cols-3 gap-3">
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-3 text-center dark:border-slate-700 dark:bg-slate-800/70">
                <div className="text-lg font-black text-white">{cards.length}</div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Steps</div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-3 text-center dark:border-slate-700 dark:bg-slate-800/70">
                <div className="text-lg font-black text-green-500">{completed || (completionResult ? cards.length : 0)}</div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Done</div>
              </div>
              <div className="rounded-2xl border border-slate-200 bg-white/80 p-3 text-center dark:border-slate-700 dark:bg-slate-800/70">
                <div className="text-lg font-black text-red-500">{failed}</div>
                <div className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Errors</div>
              </div>
            </div>

            <div className="flex flex-col gap-4">
              {cards.map((step, index) => (
                <AiWorkflowStepCard key={`${step.tag}-${index}`} step={step} running={String(step.status).toLowerCase() === "running"} />
              ))}
            </div>

            {response?.plan?.goal ? (
              <div className="mt-4 rounded-2xl border border-blue-500/20 bg-blue-500/10 p-4 text-sm leading-relaxed text-slate-800 dark:text-slate-100">
                🎯 <b>Goal:</b> {response.plan.goal}
              </div>
            ) : null}

            {response?.execution_type === "automated" || response?.plan?.needs_approval ? (
              <div className="mt-4 rounded-2xl border border-yellow-500/30 bg-yellow-500/10 p-4">
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="text-sm font-black text-slate-950 dark:text-white">⚡ Automation workflow</div>
                    <p className="mt-1 text-xs text-slate-500 dark:text-slate-400">Activate only after checking the generated workflow.</p>
                  </div>
                  <button onClick={handleActivateFlow} disabled={activatingFlow} className="rounded-full bg-red-500 px-4 py-2 text-xs font-black text-white disabled:opacity-60">
                    {activatingFlow ? "Activating..." : "Activate automation"}
                  </button>
                </div>
                {activateFlowResult ? <p className={`mt-3 text-xs font-bold ${activateFlowResult.ok ? "text-green-500" : "text-red-500"}`}>{activateFlowResult.message}</p> : null}
              </div>
            ) : null}
          </>
        )}
      </div>

      <div className="flex h-10 shrink-0 items-center justify-between border-t border-slate-200 px-4 text-xs text-slate-500 dark:border-slate-700 dark:text-slate-400">
        <span><span className="mr-2 inline-block h-2 w-2 rounded-full bg-green-500" />Live tool: <b>{liveTool}</b></span>
        <span>tokens {(response?.total_tokens || completionResult?.total_tokens || 0).toLocaleString()} · cost {response?.estimated_cost_usd != null ? `$${Number(response.estimated_cost_usd).toFixed(4)}` : "—"}</span>
      </div>
    </section>
  );
}
