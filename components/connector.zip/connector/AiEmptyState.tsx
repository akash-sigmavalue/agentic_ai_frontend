"use client";

import type { ReactNode } from "react";

function NodeMap() {
  return (
    <div className="relative mt-4 h-16 overflow-hidden rounded-2xl bg-gradient-to-r from-transparent via-blue-500/10 to-transparent">
      <span className="absolute left-[10%] top-[22%] h-2 w-2 rounded-full bg-blue-500 shadow-[0_0_18px_#4285f4]" />
      <span className="absolute left-[32%] top-[62%] h-2 w-2 rounded-full bg-red-500 shadow-[0_0_18px_#ea4335]" />
      <span className="absolute left-[58%] top-[25%] h-2 w-2 rounded-full bg-green-500 shadow-[0_0_18px_#34a853]" />
      <span className="absolute left-[82%] top-[60%] h-2 w-2 rounded-full bg-yellow-500 shadow-[0_0_18px_#fbbc04]" />
    </div>
  );
}

type AiEmptyStateProps = {
  icon: ReactNode;
  title: string;
  text: string;
};

export default function AiEmptyState({ icon, title, text }: AiEmptyStateProps) {
  return (
    <div className="flex h-full min-h-[240px] items-center justify-center text-center">
      <div>
        <div className="relative mx-auto grid h-20 w-20 place-items-center rounded-[28px] border border-blue-500/25 bg-gradient-to-br from-blue-500/20 to-red-500/10 text-4xl shadow-[0_0_70px_rgba(66,133,244,.26)]">
          {icon}
        </div>
        <h3 className="mt-8 text-base font-black text-slate-950 dark:text-white">
          {title}
        </h3>
        <p className="mx-auto mt-2 max-w-xs text-sm leading-relaxed text-slate-600 dark:text-slate-300">
          {text}
        </p>
        <NodeMap />
      </div>
    </div>
  );
}
