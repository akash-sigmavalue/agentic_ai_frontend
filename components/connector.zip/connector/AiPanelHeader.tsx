"use client";

import type { ReactNode } from "react";

type AiPanelHeaderProps = {
  icon: ReactNode;
  kicker: string;
  title: string;
  right?: ReactNode;
  status?: boolean;
};

export default function AiPanelHeader({
  icon,
  kicker,
  title,
  right,
  status = true,
}: AiPanelHeaderProps) {
  return (
    <div className="flex h-[66px] shrink-0 items-center justify-between border-b border-slate-200/70 px-5 dark:border-slate-700/80">
      <div className="flex min-w-0 items-center gap-3">
        <div className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-blue-500/15 text-lg text-blue-500">
          {icon}
        </div>
        <div className="min-w-0">
          <div className="truncate text-[10px] font-black uppercase tracking-[0.2em] text-slate-500 dark:text-slate-400">
            {kicker}
          </div>
          <div className="mt-0.5 truncate text-sm font-extrabold text-slate-950 dark:text-white">
            {status ? <span className="mr-2 inline-block h-2 w-2 rounded-full bg-green-500" /> : null}
            {title}
          </div>
        </div>
      </div>
      {right ? <div className="shrink-0">{right}</div> : null}
    </div>
  );
}
