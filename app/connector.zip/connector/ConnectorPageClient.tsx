"use client";

import React, { useEffect, useRef, useState } from "react";
import Link from "next/link";
// import Header from "../../../components/shared/Header";
import { LayoutDashboard, History, Settings, Plug } from "lucide-react";

import {
  getGmailConnectionStatus,
  continueMissingField,
  saveAutomationFlow,
  streamWorkflowRun,
  startGoogleOAuth,
} from "../../components/connector/api";

import ChatSectionConnector from "../../components/connector/chatsectionconnector";
import WorkflowSectionConnector from "../../components/connector/workflowsectionconnector";
import OutputSectionConnector from "../../components/connector/outputsectionconnector";
import type {
  CompletionResult,
  ConvMessage,
  ConvStep,
  StreamStep,
  WorkflowResponse,
} from "../../components/connector/types";

function hasGmailStep(response: WorkflowResponse | null) {
  return response?.plan?.steps?.some((step) => step.system === "gmail") ?? false;
}

function isGmailNotConnectedError(error: unknown) {
  const message = error instanceof Error ? error.message : String(error);
  return /gmail is not connected/i.test(message) || /connect google oauth/i.test(message);
}

function responseRequiresGmailOAuth(response: WorkflowResponse | null) {
  if (!response) return false;

  if (response.requires_oauth && response.connector === "gmail") {
    return true;
  }

  return (
    response.raw_mcp_results?.some(
      (item) => item.connector === "gmail" && item.requires_oauth === true
    ) ?? false
  );
}

function normalizeExecutionType(value: string): "one_time" | "automated" {
  const normalized = value.trim().toLowerCase();

  if (
    [
      "one_time",
      "one-time",
      "one time",
      "once",
      "just once",
      "run once",
      "single run",
    ].includes(normalized)
  ) {
    return "one_time";
  }

  if (
    [
      "automated",
      "automatic",
      "automation",
      "auto",
      "every time",
      "each time",
      "always",
    ].includes(normalized)
  ) {
    return "automated";
  }

  return normalized === "one_time" ? "one_time" : "automated";
}

function looksLikeEmail(value: string) {
  return /^[\w.-]+@[\w.-]+\.\w+$/.test(value.trim());
}

export default function ConnectorPageClient() {
  const abortRef = useRef<AbortController | null>(null);

  const [prompt, setPrompt] = useState("Read my Gmail attachments and summarize them");
  const [isLoading, setIsLoading] = useState(false);
  const [connectorStatusLoading, setConnectorStatusLoading] = useState(false);
  const [statusMessage, setStatusMessage] = useState("Prompt workflow workspace ready.");
  const [response, setResponse] = useState<WorkflowResponse | null>(null);
  const [streamingSteps, setStreamingSteps] = useState<StreamStep[]>([]);
  const [convStep, setConvStep] = useState<ConvStep>("idle");
  const [convMessages, setConvMessages] = useState<ConvMessage[]>([]);
  const [collectedEmail, setCollectedEmail] = useState<string | null>(null);
  const [collectedFrequency, setCollectedFrequency] = useState<
    "one_time" | "automated" | null
  >(null);
  const [currentMissingField, setCurrentMissingField] = useState<string | null>(null);
  const [currentFieldType, setCurrentFieldType] = useState<
    "email" | "choice" | "text" | "text_optional"
  >("text");
  const [currentFieldOptions, setCurrentFieldOptions] = useState<string[]>([]);
  const [currentFieldSkippable, setCurrentFieldSkippable] = useState(false);
  const [currentFieldQuestion, setCurrentFieldQuestion] = useState<string | null>(null);
  const [partialIntent, setPartialIntent] = useState<
    Record<string, unknown> | null
  >(null);
  const [completionResult, setCompletionResult] =
    useState<CompletionResult | null>(null);
  const [activatingFlow, setActivatingFlow] = useState(false);
  const [activateFlowResult, setActivateFlowResult] = useState<{
    ok: boolean;
    message: string;
  } | null>(null);

  const [needsGmail, setNeedsGmail] = useState(false);
  const [gmailConnected, setGmailConnected] = useState(false);
  const [gmailEmail, setGmailEmail] = useState<string | null>(null);
  const [pendingPrompt, setPendingPrompt] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    const ensureGoogleConnection = async () => {
      setConnectorStatusLoading(true);

      try {
        const status = await getGmailConnectionStatus();

        if (cancelled) {
          return;
        }

        setGmailConnected(status.connected);
        setGmailEmail(status.email ?? null);

        if (status.connected) {
          setNeedsGmail(false);
          setPendingPrompt(null);
          setStatusMessage(
            status.email ? `Gmail connected as ${status.email}.` : "Gmail connected."
          );
          return;
        }

        setStatusMessage("Gmail connection is required. Starting Google OAuth...");
        const data = await startGoogleOAuth();
        if (cancelled) {
          return;
        }

        const popup = window.open(data.auth_url, "_blank", "width=600,height=700");
        if (!popup) {
          setStatusMessage("Popup blocked. Please allow popups to connect Gmail.");
        }
      } catch {
        if (!cancelled) {
          setStatusMessage(
            "Gmail connection is required. Please sign in with Google first."
          );
        }
      } finally {
        if (!cancelled) {
          setConnectorStatusLoading(false);
        }
      }
    };

    ensureGoogleConnection();

    return () => {
      cancelled = true;
    };
  }, []);

  const clearGmailState = () => {
    setNeedsGmail(false);
    setGmailConnected(false);
    setGmailEmail(null);
    setPendingPrompt(null);
  };

  const setGmailRequiredState = (promptToKeep: string, message: string) => {
    setNeedsGmail(true);
    setGmailConnected(false);
    setGmailEmail(null);
    setPendingPrompt(promptToKeep);
    setStatusMessage(message);
  };

  const syncGmailConnectionStatus = async (promptToKeep: string) => {
    setConnectorStatusLoading(true);

    try {
      const status = await getGmailConnectionStatus();

      setGmailConnected(status.connected);
      setGmailEmail(status.email ?? null);

      if (status.connected) {
        setNeedsGmail(false);
        setPendingPrompt(null);
        setStatusMessage(
          status.email ? `Gmail connected as ${status.email}.` : "Gmail connected."
        );
      } else {
        setGmailRequiredState(
          promptToKeep,
          "Gmail connection is required. Please connect your account first."
        );
      }
    } catch {
      setGmailRequiredState(
        promptToKeep,
        "Gmail connection is required. Please connect your account first."
      );
    } finally {
      setConnectorStatusLoading(false);
    }
  };

  const handleRunWorkflow = async (promptOverride?: string) => {
    // Cancel any previous in-flight stream
    abortRef.current?.abort();
    abortRef.current = new AbortController();

    const sourcePrompt = typeof promptOverride === "string" ? promptOverride : prompt;
    const cleaned = sourcePrompt.trim();

    if (!cleaned) {
      setStatusMessage("Enter a prompt first.");
      return;
    }
     console.log("Running workflow with prompt:", cleaned);

    // Append user message to conversation (preserving history like a chat)
    setConvMessages((prev) => [...prev, { role: "user", text: cleaned }]);

    setConvStep("idle");
    setCollectedEmail(null);
    setCollectedFrequency(null);
    setCurrentMissingField(null);
    setCurrentFieldType("text");
    setCurrentFieldOptions([]);
    setCurrentFieldSkippable(false);
    setCurrentFieldQuestion(null);
    setPartialIntent(null);
    setCompletionResult(null);
    setActivatingFlow(false);
    setActivateFlowResult(null);
    setResponse(null);
    setStreamingSteps([]);

    setIsLoading(true);
    setStatusMessage("Checking Gmail connection...");

    try {
      const connectionStatus = await getGmailConnectionStatus();

      if (!connectionStatus.connected) {
        setGmailRequiredState(
          cleaned,
          "Gmail connection is required. Please connect your account first."
        );
        return;
      }

      setNeedsGmail(false);
      setGmailConnected(true);
      setGmailEmail(connectionStatus.email ?? null);
      setPendingPrompt(null);

      setStatusMessage("Running workflow — watching agent steps live...");
      setConvStep("streaming");

      // Stream the workflow execution step-by-step
      await streamWorkflowRun({
        prompt: cleaned,
        signal: abortRef.current.signal,

        onStep: (step) => {
           console.log("Agent Step:", step);
           
          setStreamingSteps((prev) => {
            // Upsert: replace if step number already exists (running → completed)
            const idx = prev.findIndex((s) => s.step === step.step);
            if (idx !== -1) {
              const next = [...prev];
              next[idx] = step;
              return next;
            }
            return [...prev, step];
          });
        },

        onComplete: (result) => {
          console.log("Final workflow result:", result);
          const workflowResponse = result as unknown as WorkflowResponse;
           
           console.log("Final parsed response:", workflowResponse);
           console.log("Partial Intent:", workflowResponse.partial_intent);
           console.log("Missing Field:", workflowResponse.missing_field);

          setResponse(workflowResponse);

          if (workflowResponse.missing_field && workflowResponse.partial_intent) {
            setPartialIntent(workflowResponse.partial_intent);
            setCurrentMissingField(workflowResponse.missing_field);
            setCurrentFieldType(workflowResponse.field_type || "text");
            setCurrentFieldOptions(workflowResponse.field_options || []);
            setCurrentFieldSkippable(workflowResponse.field_skippable || false);
            setCurrentFieldQuestion(
              workflowResponse.question ||
                "Please provide a bit more information so I can continue."
            );
            const question =
              workflowResponse.missing_field_question ||
              workflowResponse.message ||
              "Please provide the email address to continue.";
            setConvMessages((prev) => [
              ...prev,
              {
                role: "assistant",
                text: question,
                content: question,
              },
            ]);
            setConvStep("waiting_field");
            setStatusMessage("I need a bit more information to continue.");
            setIsLoading(false);
            return;
          }

          if (responseRequiresGmailOAuth(workflowResponse)) {
            setGmailRequiredState(
              cleaned,
              workflowResponse.error ||
                "Gmail connection is required. Please connect your account first."
            );
          } else {
            clearGmailState();
            setStatusMessage("Workflow completed successfully.");
          }
          setConvStep("done");
          setIsLoading(false);
        },

        onError: (error) => {
          if (isGmailNotConnectedError(new Error(error))) {
            setGmailRequiredState(
              cleaned,
              "Gmail connection is required. Please connect your account first."
            );
          } else {
            setStatusMessage(error);
          }
          setConvStep("idle");
          setIsLoading(false);
        },
      });
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Unable to generate workflow.";

      if (isGmailNotConnectedError(error)) {
        setGmailRequiredState(
          cleaned,
          "Gmail connection is required. Please connect your account first."
        );
        return;
      }

      setStatusMessage(message);
      setConvStep("idle");
    } finally {
      // isLoading is managed in onComplete/onError callbacks
    }
  };

  const handleConvUserReply = async (input: string) => {
    const trimmed = input.trim();
    if (!trimmed) return;

    setConvMessages((prev) => [...prev, { role: "user", text: trimmed }]);

    if (
      convStep === "waiting_field" ||
      convStep === "waiting_email" ||
      convStep === "waiting_frequency"
    ) {
      const activeField =
        currentMissingField ||
        (convStep === "waiting_email"
          ? "sender_email"
          : convStep === "waiting_frequency"
            ? "execution_type"
            : null);
      if (!activeField) return;

      const isSkip =
        trimmed.toLowerCase() === "skip" ||
        (currentFieldSkippable && trimmed === "");
      if (currentFieldType === "email" && !isSkip && !looksLikeEmail(trimmed)) {
        setStatusMessage("Please enter a valid email address.");
        setConvMessages((prev) => prev.slice(0, -1));
        return;
      }

      const normalizedValue =
        activeField === "execution_type"
          ? normalizeExecutionType(trimmed)
          : trimmed;

      setCollectedEmail(activeField === "sender_email" && !isSkip ? normalizedValue : collectedEmail);
      setCollectedFrequency(
        activeField === "execution_type" && !isSkip
          ? (normalizedValue as "one_time" | "automated")
          : collectedFrequency,
      );
      setConvStep("submitting");
      setStatusMessage("Setting up your workflow...");
      setIsLoading(true);

      try {
        const result = await continueMissingField({
          missing_field: activeField,
          user_answer: isSkip ? "__skip__" : normalizedValue,
          partial_intent: {
            ...partialIntent,
            [activeField]: isSkip ? null : normalizedValue,
            answered_fields: [
              ...(((partialIntent as any)?.answered_fields as string[] | undefined) || []),
              activeField,
            ],
          },
        });

        if (result.missing_field && result.partial_intent) {
          setResponse((prev) =>
            prev
              ? {
                  ...prev,
                  ...result,
                }
              : {
                  ...result,
                }
          );
          setPartialIntent(result.partial_intent);
          setCurrentMissingField(result.missing_field);
          setCurrentFieldType(result.field_type || "text");
          setCurrentFieldOptions(result.field_options || []);
          setCurrentFieldSkippable(result.field_skippable || false);
          setCurrentFieldQuestion(result.question || "Please provide more details.");
          setConvStep("waiting_field");
          setStatusMessage("I need a bit more information to continue.");
          setConvMessages((prev) => [
            ...prev,
            {
              role: "agent",
              text: result.question || "Please provide more details.",
            },
          ]);
          return;
        }

        const completion = result as CompletionResult;
        setCompletionResult(completion);
        setResponse((prev) =>
          ({
            ...(prev || {}),
            ...completion,
            missing_field: undefined,
            question: undefined,
            field_type: undefined,
            field_options: undefined,
            field_skippable: undefined,
            partial_intent: undefined,
          } as WorkflowResponse)
        );
        setConvStep("done");
        setStatusMessage(completion.message || "Workflow set up successfully.");
        setConvMessages((prev) => [
          ...prev,
          {
            role: "agent",
            text: completion.message || "Done! Your workflow is active.",
          },
        ]);
      } catch (error) {
        const msg = error instanceof Error ? error.message : "Something went wrong.";
        setStatusMessage(msg);
        setConvStep("idle");
      } finally {
        setCurrentMissingField(null);
        setCurrentFieldQuestion(null);
        setIsLoading(false);
      }
    }
  };

  const handleConnectGmail = async () => {
    try {
      const data = await startGoogleOAuth();
      const popup = window.open(data.auth_url, "_blank", "width=600,height=700");

      if (!popup) {
        setStatusMessage("Popup blocked. Please allow popups to connect Gmail.");
        return;
      }

      setStatusMessage(
        "Gmail setup opened. Complete Google sign-in, then recheck the connection."
      );
    } catch (error) {
      setStatusMessage(
        error instanceof Error ? error.message : "Unable to start Google OAuth."
      );
    }
  };

  const handleRecheckGmailConnection = async () => {
    if (!pendingPrompt && !hasGmailStep(response)) {
      setStatusMessage("No Gmail workflow is waiting for a connection.");
      return;
    }

    const promptToResume = pendingPrompt ?? prompt.trim();

    setConnectorStatusLoading(true);
    try {
      const status = await getGmailConnectionStatus();

      setGmailConnected(status.connected);
      setGmailEmail(status.email ?? null);

      if (!status.connected) {
        setGmailRequiredState(
          promptToResume,
          "Gmail connection is required. Please connect your account first."
        );
        return;
      }

      setNeedsGmail(false);
      setStatusMessage(
        status.email ? `Gmail connected as ${status.email}.` : "Gmail connected."
      );

      if (pendingPrompt) {
        await handleContinueWorkflow();
      }
    } catch (error) {
      setGmailRequiredState(
        promptToResume,
        error instanceof Error ? error.message : "Unable to verify Gmail connection."
      );
    } finally {
      setConnectorStatusLoading(false);
    }
  };

  const handleContinueWorkflow = async () => {
    if (!pendingPrompt) {
      setStatusMessage("No pending workflow to continue.");
      return;
    }

    try {
      const status = await getGmailConnectionStatus();
      if (!status.connected) {
        setGmailRequiredState(
          pendingPrompt,
          "Gmail connection is required. Please connect your account first."
        );
        return;
      }
      setGmailConnected(true);
      setGmailEmail(status.email ?? null);
      setNeedsGmail(false);
    } catch (error) {
      setGmailRequiredState(
        pendingPrompt,
        error instanceof Error ? error.message : "Unable to verify Gmail connection."
      );
      return;
    }

    await handleRunWorkflow(pendingPrompt);
  };

  const handleActivateFlow = async () => {
    if (!response?.can_execute || !response.flow) {
      setActivateFlowResult({
        ok: false,
        message: "No executable automation flow is available.",
      });
      return;
    }

    setActivatingFlow(true);
    setActivateFlowResult(null);

    try {
      const result = await saveAutomationFlow({ flow: response.flow });
      setActivateFlowResult({
        ok: true,
        message:
          "Automation activated! It will run on every new email.",
      });
      setStatusMessage(`Automation saved as rule #${result.rule_id}.`);
    } catch (error) {
      const message =
        error instanceof Error ? error.message : "Failed to activate automation.";
      setActivateFlowResult({
        ok: false,
        message,
      });
      setStatusMessage(message);
    } finally {
      setActivatingFlow(false);
    }
  };

  return (
  <main className="relative flex h-screen w-full flex-col overflow-hidden bg-[#f8fafc] text-slate-900">
    {/* <Header /> */}

    <aside className="fixed bottom-0 left-0 top-16 z-40 hidden w-16 flex-col items-center border-r border-slate-200/60 bg-white py-5 shadow-sm lg:flex">
      <div className="flex w-full flex-1 flex-col items-center gap-5">
        <button className="p-3 text-slate-400 transition-all hover:text-[#525ceb]">
          <div className="flex flex-col items-center gap-1">
            <div className="h-0.5 w-6 rounded-full bg-current" />
            <div className="h-0.5 w-6 rounded-full bg-current" />
          </div>
        </button>

        <div className="flex flex-col gap-3">
          <Link
            href="/dashboard"
            title="Dashboard"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-100/80 text-slate-400 transition-all duration-300 hover:border-indigo-200 hover:bg-slate-50 hover:text-indigo-600"
          >
            <LayoutDashboard className="h-5 w-5" />
          </Link>

          <Link
            href="/dashboard?tab=history"
            title="History"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-100/80 text-slate-400 transition-all duration-300 hover:border-indigo-200 hover:bg-slate-50 hover:text-indigo-600"
          >
            <History className="h-5 w-5" />
          </Link>

          <Link
            href="/dashboard?tab=settings"
            title="Settings"
            className="flex h-11 w-11 items-center justify-center rounded-xl border border-slate-200/80 bg-slate-100/80 text-slate-400 transition-all duration-300 hover:border-indigo-200 hover:bg-slate-50 hover:text-indigo-600"
          >
            <Settings className="h-5 w-5" />
          </Link>

          <div
            title="Connector"
            className="flex h-11 w-11 items-center justify-center rounded-xl bg-[#525ceb] text-white shadow-lg shadow-indigo-200"
          >
            <Plug className="h-5 w-5" />
          </div>
        </div>
      </div>

      <div className="mb-4 mt-auto">
        <div className="flex h-9 w-9 items-center justify-center rounded-full border border-slate-200 bg-slate-100 text-sm font-black text-[#1a1c3d] shadow-sm">
          C
        </div>
      </div>
    </aside>

    <div
      className="pointer-events-none absolute inset-0 opacity-[0.18]"
      style={{
        backgroundImage: "radial-gradient(#cbd5e1 1px, transparent 1px)",
        backgroundSize: "28px 28px",
      }}
    />

    <div className="relative z-10 flex h-[calc(100vh-64px)] min-h-0 flex-col pt-16 lg:ml-16">
      <section className="grid h-full min-h-0 gap-4 overflow-hidden p-4 
        grid-cols-1 
        lg:grid-cols-[0.85fr_1.15fr] 
        2xl:grid-cols-[0.85fr_1.05fr_1fr]"
      >
        <div className="min-h-0 overflow-hidden">
          <ChatSectionConnector
            prompt={prompt}
            setPrompt={setPrompt}
            isLoading={isLoading}
            statusMessage={statusMessage}
            handleRunWorkflow={handleRunWorkflow}
            convStep={convStep}
            convMessages={convMessages}
            handleConvUserReply={handleConvUserReply}
            currentFieldName={currentMissingField}
            currentFieldType={currentFieldType}
            currentFieldOptions={currentFieldOptions}
            currentFieldSkippable={currentFieldSkippable}
            currentFieldQuestion={currentFieldQuestion}
          />
        </div>

        <div className="min-h-0 overflow-hidden">
          <WorkflowSectionConnector
            response={response}
            needsGmail={needsGmail}
            gmailConnected={gmailConnected}
            gmailEmail={gmailEmail}
            pendingPrompt={pendingPrompt}
            isLoading={isLoading}
            connectorStatusLoading={connectorStatusLoading}
            handleConnectGmail={handleConnectGmail}
            handleRecheckGmailConnection={handleRecheckGmailConnection}
            handleContinueWorkflow={handleContinueWorkflow}
            handleActivateFlow={handleActivateFlow}
            activatingFlow={activatingFlow}
            activateFlowResult={activateFlowResult}
            completionResult={completionResult}
            convStep={convStep}
            streamingSteps={streamingSteps}
          />
        </div>

        <div className="min-h-0 overflow-hidden lg:col-span-2 2xl:col-span-1">
          <OutputSectionConnector
            response={response}
            completionResult={completionResult}
            partialIntent={partialIntent}
            convStep={convStep}
            onSendPrompt={handleRunWorkflow}
          />
        </div>
      </section>
    </div>
  </main>
);
}
